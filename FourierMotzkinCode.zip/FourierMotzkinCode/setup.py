# -*- coding: utf-8 -*-
"""
Created on Tue Oct 23 15:55:10 2018

@author: sadra
"""

from distutils.core import setup

setup(
    name='pyfomo',
    version='0.1dev',
    packages=[],
    license='MIT',
    long_description=open('README.md').read(),
    author='Sadra Sadraddini',
    author_email='sadra@mit.edu',
)