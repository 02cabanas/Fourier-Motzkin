# -*- coding: utf-8 -*-
print("\n\n\n")

from tokenize import String
from typing import *


# Story 10 method / function
def getNumOfVar() -> int:
    numofvar = int(input("\nHow many different variables would you like?\nPlease type an integer Number:\n"))
    print("\nYou want %d different variables. "%numofvar)
    correct = str(input("Is this correct (Y/n)?\n"))
    if correct == "Y":
        return numofvar
    else:
        return getNumOfVar()

# Story 11 method / function
def getVarNames() -> List[str]:
    listofvar = str(input("\nWhat variable names would you like?\nPlease type words (strings) seperated by tabs:\n"))
    listofvar = listofvar.split("\t")
    print("\nYou want the following variable names: %s. "%listofvar)
    correct = str(input("Is this correct (Y/n)?\n"))
    if correct == "Y":
        return listofvar
    else:
        return getVarNames()

# Story 12 method / function
def intToVarList(numofvar: int) -> List[str]:
    listofvar = list()
    for i in range(1, numofvar + 1):
        tempstr = "X" + str(i)
        SUB = str.maketrans("0123456789", "₀₁₂₃₄₅₆₇₈₉")
        tempstr.translate(SUB)
        listofvar.append(tempstr)
    return listofvar

# method getting users preference for inputing variable names generate classical inequalities
def varinput() -> List[str]:
    varinputoption = int(input("Select one of two options...\n\n(1)\tInput the number of variables desired to generate classical inequalities\n(2)\tInput the desired names of the variables from which to generate classical inequalities\t\n\nPlease type an integer; either '1' or '2'\n"))
    if varinputoption == 1:
        numofvar = getNumOfVar()
        listofvar = intToVarList(numofvar)
        return listofvar
    elif varinputoption == 2:
        listofvar = getVarNames()
        return listofvar
    else:
        print("\nInvalid selection. Please", end=" ")
        return varinput()

# get variable input from user and saves it to
listofvar = varinput()

# print List of variables
print("\nList of variables:\n")
for str in listofvar:
    print(str, end=", ")
print("\n                  \n")